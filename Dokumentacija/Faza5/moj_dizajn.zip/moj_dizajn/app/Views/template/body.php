    <div class="grid_content">
        <div class="grid_content_left">
            <div class="lista_dizajnera">
            </div>
            <div class="galerija">
                Galerija
            </div>
        </div>
    </div>
</div>
</body>

</html>