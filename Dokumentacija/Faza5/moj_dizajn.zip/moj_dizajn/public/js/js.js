function alo(){
    alert("alo");
}

